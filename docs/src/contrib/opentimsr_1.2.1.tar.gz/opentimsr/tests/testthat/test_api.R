library(opentimsr)

setup_opensource()
D <- OpenTIMS(system.file("extdata", "test.d", package = "opentimsr"))

raw_columns <- c("frame", "scan", "tof", "intensity")

# --- frame metadata ---

test_that("frame bounds are consistent", {
  expect_gte(D@min_frame, 1L)
  expect_gte(D@max_frame, D@min_frame)
  expect_equal(nrow(D@frames), D@max_frame - D@min_frame + 1L)
})

test_that("scan bounds are 0-based: 0 .. NumScans - 1", {
  expect_equal(D@min_scan, 0L)
  expect_equal(D@max_scan, as.integer(max(D@frames$NumScans)) - 1L)
  expect_equal(min_max_measurements(D)$scan, c(D@min_scan, D@max_scan))
})

test_that("retention times have one entry per frame and are monotone", {
  rts <- retention_times(D)
  expect_length(rts, nrow(D@frames))
  expect_true(all(diff(rts) >= 0))
})

test_that("MS1 frames are a subset of all frames", {
  expect_true(all(MS1(D) %in% D@frames$Id))
})

test_that("peaks_per_frame_cnts sums to length", {
  expect_equal(sum(peaks_per_frame_cnts(D)), length(D))
})

test_that("min_max_measurements has min and max rows", {
  mm <- min_max_measurements(D)
  expect_equal(mm$stat, c("min", "max"))
  expect_true(all(mm$frame[1] <= mm$frame[2]))
})

# --- query ---

test_that("query returns requested columns", {
  result <- query(D, frames = c(1L, 2L), columns = raw_columns)
  expect_s3_class(result, "data.frame")
  expect_equal(colnames(result), raw_columns)
})

test_that("query frame and scan values are in range", {
  result <- query(D, frames = D@frames$Id, columns = c("frame", "scan"))
  expect_true(all(result$frame >= D@min_frame & result$frame <= D@max_frame))
  expect_true(all(result$scan >= D@min_scan & result$scan <= D@max_scan))
})

test_that("query intensities are positive", {
  result <- query(D, frames = D@frames$Id, columns = "intensity")
  expect_true(all(result$intensity > 0L))
})

test_that("query of a single frame returns only that frame", {
  result <- query(D, frames = D@min_frame, columns = raw_columns)
  expect_true(all(result$frame == D@min_frame))
})

test_that("query rejects unknown columns", {
  expect_error(query(D, frames = 1L, columns = "nonsense"), "Wrong column names")
})

test_that("query rejects frames not in the dataset", {
  expect_error(query(D, D@max_frame + 1L), "No such frame")
  expect_error(query(D, 0L), "No such frame")
  expect_error(query(D, c(1L, -1L)), "No such frame")
})

test_that("query rejects non-whole and NA frame numbers", {
  expect_error(query(D, 1.5), "whole numbers")
  expect_error(query(D, NA), "whole numbers")
  expect_error(query(D, "1"), "whole numbers")
})

# --- query_slice ---

test_that("query_slice over all frames matches query", {
  from_slice <- query_slice(D, columns = raw_columns)
  from_query <- query(D, frames = D@frames$Id, columns = raw_columns)
  expect_equal(from_slice, from_query)
})

test_that("query_slice of a single frame matches query", {
  from_slice <- query_slice(D, D@min_frame, D@min_frame, columns = raw_columns)
  from_query <- query(D, frames = D@min_frame, columns = raw_columns)
  expect_equal(from_slice, from_query)
})

test_that("empty query_slice returns no rows", {
  result <- query_slice(D, D@max_frame, D@min_frame, columns = raw_columns)
  expect_equal(nrow(result), 0L)
})

test_that("query_slice rejects out-of-range bounds and non-positive steps", {
  expect_error(query_slice(D, D@min_frame - 1L, D@max_frame), "out of range")
  expect_error(query_slice(D, D@min_frame, D@max_frame + 1L), "out of range")
  expect_error(query_slice(D, D@min_frame, D@max_frame, 0), "'by' must be positive")
  expect_error(query_slice(D, D@min_frame, D@max_frame, -1), "'by' must be positive")
  expect_error(query_slice(D, 1.5, D@max_frame), "single whole numbers")
})

# --- rt_query ---

test_that("rt_query over the full retention time range matches query_slice", {
  rts <- retention_times(D)
  expect_equal(rt_query(D, min(rts), max(rts), columns = raw_columns),
               query_slice(D, columns = raw_columns))
})

test_that("rt_query outside the data raises", {
  expect_error(rt_query(D, -2, -1), "does not hold any data")
})

test_that("rt_query returns frame ids, not positions, when ids have gaps", {
  src <- system.file("extdata", "test.d", package = "opentimsr")
  gapped <- file.path(tempfile(), "gapped.d")
  dir.create(gapped, recursive = TRUE)
  file.copy(file.path(src, c("analysis.tdf", "analysis.tdf_bin")), gapped)
  conn <- DBI::dbConnect(RSQLite::SQLite(), file.path(gapped, "analysis.tdf"))
  DBI::dbExecute(conn, "UPDATE Frames SET Id = CASE Id WHEN 2 THEN 5 ELSE Id END")
  DBI::dbDisconnect(conn)

  G <- OpenTIMS(gapped)
  on.exit(CloseTIMS(G))
  rts <- retention_times(G)
  expect_equal(sort(unique(rt_query(G, min(rts), max(rts))$frame)), c(1L, 5L))
  expect_equal(unique(rt_query(G, rts[2], rts[2])$frame), 5L)
  expect_equal(nrow(rt_query(G, rts[1] + 1e-6, rts[2] - 1e-6)), 0L)
})

# --- OpenTIMS methods ---

test_that("[ returns peaks of the requested frame", {
  result <- D[D@min_frame]
  expect_true(all(result$frame == D@min_frame))
})

test_that("[ rejects frames out of range", {
  expect_error(D[D@max_frame + 1L], "No such frame")
})

test_that("range rejects out-of-range bounds and non-positive steps", {
  expect_error(range(D, D@min_frame - 1L, D@max_frame), "out of range")
  expect_error(range(D, D@min_frame, D@max_frame + 2L), "out of range")
  expect_error(range(D, D@min_frame, D@max_frame, 0), "'by' must be positive")
})

test_that("range covers all peaks", {
  result <- range(D, D@min_frame, D@max_frame + 1L)
  expect_equal(nrow(as.data.frame(result)), length(D))
})

# --- SQLite tables ---

test_that("tables_names lists Frames and GlobalMetadata", {
  expect_true(all(c("Frames", "GlobalMetadata") %in% tables_names(D)))
})

test_that("table2df returns the Frames table", {
  frames <- table2df(D, "Frames")
  expect_equal(frames$Frames$Id, D@frames$Id)
})

CloseTIMS(D)

test_that("OpenTIMS rejects a missing folder", {
  expect_error(OpenTIMS(file.path(tempdir(), "no_such_folder.d")), "no_such_folder.d", fixed = TRUE)
})

test_that("OpenTIMS does not create analysis.tdf in a folder lacking it", {
  path.d <- file.path(tempfile(), "empty.d")
  dir.create(path.d, recursive = TRUE)
  expect_error(OpenTIMS(path.d))
  expect_false(file.exists(file.path(path.d, "analysis.tdf")))
})
