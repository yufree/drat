/*
 *   OpenTIMS: a fully open-source library for opening Bruker's TimsTOF data files.
 *   Copyright (C) 2020-2026 Michał Startek and Mateusz Łącki
 *
 *   Licensed under the MIT License. See LICENCE file in the project root for details.
 */

#pragma once

#include <string>

void setup_bruker(const std::string& path);
void setup_opensource();

extern "C" {
    void setup_bruker_c(const char* path);
    void setup_opensource_c();
}
