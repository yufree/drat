/*
 *   OpenTIMS: a fully open-source library for opening Bruker's TimsTOF data files.
 *   Copyright (C) 2020-2026 Michał Startek and Mateusz Łącki
 *
 *   Licensed under the MIT License. See LICENCE file in the project root for details.
 */

#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cstdint>
#include <string>
#include <cstring>
#include <atomic>
#include <vector>
#include <iostream>
#include <memory>
#include <limits>
#include <mutex>
#include <stdexcept>
#include <thread>
#include <unordered_map>


#include "platform.h"
#ifdef OPENTIMS_BUILDING_R
#include <zstd.h>
#else
#include "zstd/zstd.h"
#endif
#include "opentims.h"
#include "tof2mz_converter.h"
#include "scan2inv_ion_mobility_converter.h"
#include "thread_mgr.h"
#include "parse_number.h"
#ifndef OPENTIMS_BUILDING_R
#include "sqlite_helper.h"
#endif

TimsFrame::TimsFrame(uint32_t _id,
                     uint32_t _num_scans,
                     uint32_t _num_peaks,
                     uint32_t _msms_type,
                     double _intensity_correction,
                     double _time,
                     uint64_t _tims_bin_offset,
                     TimsDataHandle& parent_hndl
                     )
:
    tims_bin_offset(_tims_bin_offset),
    parent_tdh(parent_hndl),
    id(_id),
    num_scans(_num_scans),
    num_peaks(_num_peaks),
    msms_type(_msms_type),
    intensity_correction(_intensity_correction),
    time(_time)
{}

TimsFrame TimsFrame::TimsFrameFromSql(char** sql_row, TimsDataHandle& parent_handle)
{
    if(sql_row == nullptr)
        throw std::runtime_error("TimsFrameFromSql: null SQL row");
    for(int i = 0; i < 7; i++)
        if(sql_row[i] == nullptr)
            throw std::runtime_error("TimsFrameFromSql: null value in SQL column " + std::to_string(i));

    return TimsFrame(
            static_cast<uint32_t>(std::strtoull(sql_row[0], nullptr, 10)),
            static_cast<uint32_t>(std::strtoull(sql_row[1], nullptr, 10)),
            static_cast<uint32_t>(std::strtoull(sql_row[2], nullptr, 10)),
            static_cast<uint32_t>(std::strtoull(sql_row[3], nullptr, 10)),
            100.0 / parse_double_c_locale(sql_row[4]),
            parse_double_c_locale(sql_row[5]),
            std::strtoull(sql_row[6], nullptr, 10),
            parent_handle
    );
}

void TimsFrame::print() const
{
#ifndef OPENTIMS_BUILDING_R
    std::cout << "Frame description: id: " << id << ", num_scans: " << num_scans << ", num_peaks: " << num_peaks << std::endl;
#endif
}


[[noreturn]] static void throw_corrupted_frame(uint32_t frame_id, const std::string& what)
{
    throw std::runtime_error("Frame " + std::to_string(frame_id) + ": " + what + ". File is either truncated or corrupted.");
}

TimsFrame::DecompressedView TimsFrame::decompress_into(char* decompression_buffer, ZSTD_DCtx* decomp_ctx) const
{
    const size_t file_size = parent_tdh.tims_data_bin.size();
    if(tims_bin_offset > file_size || file_size - tims_bin_offset < 8)
        throw_corrupted_frame(id, "data starts beyond the end of analysis.tdf_bin");

    // Packets are not 4-byte aligned in the file: copy the header words out
    // rather than dereferencing a cast pointer.
    const char* tims_bin_frame = parent_tdh.tims_data_bin.data() + tims_bin_offset;
    uint32_t tims_packet_size;
    std::memcpy(&tims_packet_size, tims_bin_frame, sizeof(tims_packet_size));
    uint32_t header_num_scans;
    std::memcpy(&header_num_scans, tims_bin_frame + 4, sizeof(header_num_scans));
    if(header_num_scans != num_scans)
        throw_corrupted_frame(id, "analysis.tdf_bin holds " + std::to_string(header_num_scans) + " scans, but the Frames table says " + std::to_string(num_scans));

    if(tims_packet_size < 8 || tims_packet_size > file_size - tims_bin_offset)
        throw_corrupted_frame(id, "compressed data size (" + std::to_string(tims_packet_size) + " bytes) is invalid or extends beyond the end of analysis.tdf_bin");

    size_t dsbytes = data_size_bytes();

    size_t dec_result = ZSTD_decompressDCtx(decomp_ctx, decompression_buffer, dsbytes, tims_bin_frame + 8, tims_packet_size - 8);
    if(ZSTD_isError(dec_result))
    {
        std::string err = "Frame " + std::to_string(id) + ": error uncompressing frame, error code: ";
        err += std::to_string(dec_result);
        err += " (";
        err += ZSTD_getErrorName(dec_result);
        err += "). File is either corrupted, or in a (yet) unsupported variant of the format.";
        throw std::runtime_error(err);
    }
    if(dec_result != dsbytes)
        throw_corrupted_frame(id, "decompressed to " + std::to_string(dec_result) + " bytes, but NumScans and NumPeaks imply " + std::to_string(dsbytes));

    const size_t dsints = data_size_ints();
    DecompressedView ret;
    ret.bytes0 = decompression_buffer;
    ret.bytes1 = ret.bytes0 + dsints;
    ret.bytes2 = ret.bytes1 + dsints;
    ret.bytes3 = ret.bytes2 + dsints;
    return ret;
}

void TimsFrame::decompress(char* decompression_buffer, ZSTD_DCtx* decomp_ctx)
{
    std::unique_ptr<char[]> own_buffer;
    if(decompression_buffer == nullptr)
    {
        own_buffer = std::make_unique<char[]>(data_size_bytes());
        decompression_buffer = own_buffer.get();
    }
    cached = decompress_into(decompression_buffer, decomp_ctx != nullptr ? decomp_ctx : parent_tdh.zstd_dctx.get());
    back_buffer = std::move(own_buffer);
}

void TimsFrame::close()
{
    cached = DecompressedView();
    back_buffer.reset(nullptr);
}

void TimsFrame::save_to_buffs(uint32_t* frame_ids,
                              uint32_t* scan_ids,
                              uint32_t* tofs,
                              uint32_t* intensities,
                              double* mzs,
                              double* inv_ion_mobilities,
                              double* retention_times,
                              ZSTD_DCtx* decomp_ctx)
{
    if(num_peaks == 0)
        return;
    if(num_scans == 0)
        throw_corrupted_frame(id, "has peaks, but no scans");

    if(cached.bytes0 != nullptr)
        decode(cached, frame_ids, scan_ids, tofs, intensities, mzs, inv_ion_mobilities, retention_times);
    else
        decode(decompress_into(parent_tdh.decompression_buffer.get(), decomp_ctx != nullptr ? decomp_ctx : parent_tdh.zstd_dctx.get()),
               frame_ids, scan_ids, tofs, intensities, mzs, inv_ion_mobilities, retention_times);
}

void TimsFrame::save_to_buffs(uint32_t* frame_ids,
                              uint32_t* scan_ids,
                              uint32_t* tofs,
                              uint32_t* intensities,
                              double* mzs,
                              double* inv_ion_mobilities,
                              double* retention_times,
                              char* decompression_buffer,
                              ZSTD_DCtx* decomp_ctx) const
{
    if(num_peaks == 0)
        return;
    if(num_scans == 0)
        throw_corrupted_frame(id, "has peaks, but no scans");

    std::unique_ptr<char[]> own_buffer;
    if(decompression_buffer == nullptr)
    {
        own_buffer = std::make_unique<char[]>(data_size_bytes());
        decompression_buffer = own_buffer.get();
    }
    std::unique_ptr<ZSTD_DCtx, decltype(&ZSTD_freeDCtx)> own_ctx(nullptr, &ZSTD_freeDCtx);
    if(decomp_ctx == nullptr)
    {
        own_ctx.reset(ZSTD_createDCtx());
        if(!own_ctx)
            throw std::bad_alloc();
        decomp_ctx = own_ctx.get();
    }
    decode(decompress_into(decompression_buffer, decomp_ctx),
           frame_ids, scan_ids, tofs, intensities, mzs, inv_ion_mobilities, retention_times);
}

void TimsFrame::decode(const DecompressedView& data,
                       uint32_t* frame_ids,
                       uint32_t* scan_ids,
                       uint32_t* tofs,
                       uint32_t* intensities,
                       double* mzs,
                       double* inv_ion_mobilities,
                       double* retention_times) const
{
    std::unique_ptr<uint32_t[]> scan_ids_hndl;
    std::unique_ptr<uint32_t[]> tofs_hndl;
    std::unique_ptr<uint32_t[]> intensities_hndl;

    if(scan_ids == nullptr && inv_ion_mobilities != nullptr)
    {
        scan_ids_hndl = std::make_unique<uint32_t[]>(num_peaks);
        scan_ids = scan_ids_hndl.get();
    }
    if(tofs == nullptr)
    {
        tofs_hndl = std::make_unique<uint32_t[]>(num_peaks);
        tofs = tofs_hndl.get();
    }
    if(intensities == nullptr)
    {
        intensities_hndl = std::make_unique<uint32_t[]>(num_peaks);
        intensities = intensities_hndl.get();
    }

    const uint32_t nnum_peaks = num_peaks;

    uint32_t peaks_processed = 0;
    // The decompressed buffer layout: first num_scans uint32s are scan headers,
    // each storing the byte offset to the start of that scan's peak data.
    // Peak data follows: interleaved TOF deltas and intensities (2 words per peak).
    size_t read_offset = num_scans;
    uint32_t accum_tofs;

    uint32_t num_scans_m1 = num_scans - 1;

    for(uint32_t scan_idx = 0; scan_idx < num_scans_m1; scan_idx++)
    {
        // Initialize to UINT32_MAX so that the first delta addition wraps around
        // correctly: the format stores 1-indexed deltas, so delta=1 means TOF index 0.
        accum_tofs = -1;

        // Scan header stores byte offset; divide by 2 (words) to get peak count
        // for this scan (difference from next scan header gives peaks in this scan).
        const uint32_t no_peaks = data[scan_idx+1] / 2;
        if(no_peaks > nnum_peaks - peaks_processed)
            throw_corrupted_frame(id, "scan headers hold more peaks than NumPeaks");

        const uint32_t for_loop_end = no_peaks + peaks_processed;

        if(scan_ids != nullptr)
            for(uint32_t ii = peaks_processed; ii < for_loop_end; ii++)
                scan_ids[ii] = scan_idx;

        for(uint32_t ii = 0; ii < no_peaks; ii++)
        {
            accum_tofs += data[read_offset];
            tofs[peaks_processed] = accum_tofs;
            read_offset++;
            intensities[peaks_processed] = data[read_offset];
            read_offset++;
            peaks_processed++;
        }
    }

    accum_tofs = -1; // same 1-indexed delta convention for the last scan

    if(scan_ids != nullptr)
        for(uint32_t ii = peaks_processed; ii < nnum_peaks; ii++)
            scan_ids[ii] = num_scans_m1;

    while(peaks_processed < nnum_peaks)
    {
        accum_tofs += data[read_offset];
        tofs[peaks_processed] = accum_tofs;
        read_offset++;
        intensities[peaks_processed] = data[read_offset];
        read_offset++;
        peaks_processed++;
    }


    // Clamped before conversion: a double out of uint32's range converts with
    // undefined behaviour. Only nonsensical AccumulationTime values (zero,
    // negative, tiny) get there; fmax also turns NaN (0 * inf) into 0.
    for(size_t idx = 0; idx < nnum_peaks; idx++)
        intensities[idx] = static_cast<uint32_t>(std::fmin(std::fmax(static_cast<double>(intensities[idx]) * intensity_correction + 0.5, 0.0), 4294967295.0));

    if(mzs != nullptr)
        parent_tdh.tof2mz_converter->convert(id, mzs, tofs, nnum_peaks);

    if(frame_ids != nullptr)
        for(size_t idx = 0; idx < nnum_peaks; idx++)
            frame_ids[idx] = id;

    if(retention_times != nullptr)
        for(size_t idx = 0; idx < nnum_peaks; idx++)
            retention_times[idx] = time;

    if(inv_ion_mobilities != nullptr)
        parent_tdh.scan2inv_ion_mobility_converter->convert(id, inv_ion_mobilities, scan_ids, nnum_peaks);
}

int tims_sql_callback(void* out, int cols, char** row, char**)
{
    if(cols != 7 || row == nullptr || row[0] == nullptr)
        throw std::runtime_error("Frames table: unexpected row (null Id, or wrong number of columns)");
    uint32_t frame_id = atol(row[0]);
    TimsDataHandle* hndl = reinterpret_cast<TimsDataHandle*>(out);
    hndl->frame_descs.emplace(frame_id, TimsFrame::TimsFrameFromSql(row, *hndl));
    return 0;
}

void check_compression_type(const char* compression_type)
{
    if(atoi(compression_type) != 2)
    {
        std::string error_msg = "Compression algorithm used in your TDF dataset: ";
        error_msg += compression_type;
        error_msg += " is not (yet) supported by OpenTIMS. Right now only algorithm 2 (zstd) is supported.";
        throw std::runtime_error(error_msg);
    }
}

int check_compression(void*, int cols, char** row, char**)
{
    if(cols != 1 || row == nullptr || row[0] == nullptr)
        throw std::runtime_error("GlobalMetadata: TimsCompressionType has no value");
    check_compression_type(row[0]);
    return 0;
}

void TimsDataHandle::read_sql(const std::string& tims_tdf_path)
{
#ifndef OPENTIMS_BUILDING_R
    RAIISqlite DB(tims_tdf_path);

    const std::string sql = "SELECT Id, NumScans, NumPeaks, MsMsType, AccumulationTime, Time, TimsId from Frames;";

    DB.query(sql, tims_sql_callback, this);
    DB.query("SELECT Value FROM GlobalMetadata WHERE Key == \"TimsCompressionType\";", check_compression, nullptr);
#endif
}


void TimsDataHandle::init(pressure_compensation_strategy pcs,
                          Tof2MzConverterFactory* tof_factory,
                          Scan2InvIonMobilityConverterFactory* im_factory)
{
    _min_frame_id = (std::numeric_limits<uint32_t>::max)();
    _max_frame_id = (std::numeric_limits<uint32_t>::min)();
    decomp_buffer_size = 0;
    for(auto it = frame_descs.begin(); it != frame_descs.end(); it++)
    {
        _min_frame_id = (std::min)(_min_frame_id, it->first);
        _max_frame_id = (std::max)(_max_frame_id, it->first);
        decomp_buffer_size = (std::max)(decomp_buffer_size, it->second.data_size_bytes());
    }
    decompression_buffer = std::make_unique<char[]>(decomp_buffer_size);

    zstd_dctx.reset(ZSTD_createDCtx());

    tof2mz_converter = tof_factory
        ? tof_factory->produce(*this, pcs)
        : DefaultTof2MzConverterFactory::produceDefaultConverterInstance(*this, pcs);
    scan2inv_ion_mobility_converter = im_factory
        ? im_factory->produce(*this, pcs)
        : DefaultScan2InvIonMobilityConverterFactory::produceDefaultConverterInstance(*this, pcs);
}

TimsDataHandle::TimsDataHandle(const std::string& tims_tdf_bin_path, const std::string& tims_tdf_path, const std::string& tims_data_dir, pressure_compensation_strategy pcs, Tof2MzConverterFactory* tof_factory, Scan2InvIonMobilityConverterFactory* im_factory)
: tims_dir_path(tims_data_dir), tims_data_bin(tims_tdf_bin_path), zstd_dctx(nullptr, &ZSTD_freeDCtx)
{
#ifndef OPENTIMS_BUILDING_R
    read_sql(tims_tdf_path);
    init(pcs, tof_factory, im_factory);
#else
    // R builds: the R-side constructor fills frames and metadata first, then calls init() itself.
    (void)tims_tdf_path; (void)pcs; (void)tof_factory; (void)im_factory;
#endif
}

TimsDataHandle::TimsDataHandle(const std::string& tims_data_dir, pressure_compensation_strategy pcs, Tof2MzConverterFactory* tof_factory, Scan2InvIonMobilityConverterFactory* im_factory)
: TimsDataHandle(tims_data_dir + "/analysis.tdf_bin", tims_data_dir + "/analysis.tdf", tims_data_dir, pcs, tof_factory, im_factory)
{}

#ifdef OPENTIMS_BUILDING_R

union braindead_r
{
    double as_dbl;
    int64_t as_int;
};

template<typename T> std::vector<T> braindead_r_extract_as_int(const SEXP& vec)
{
    /* Quick and dirty workaround for R being braindead.
     * R holds integers as either IntegerVector or as NumericVector depending on size.
     * Converting a NumericVector to IntegerVector fails silently, giving zeros.
     * This function forces it to a sensible C++ int type.
     */

    std::vector<T> res;

    if(Rf_isInteger(vec))
    {
        Rcpp::IntegerVector vint(vec);
        res.reserve(vint.size());
        for(int ii=0; ii<vint.size(); ii++)
            res.push_back(vint[ii]);
        return res;
    }
    else
    {
        braindead_r converter;
        Rcpp::NumericVector vnum(vec);
        res.reserve(vnum.size());
        for(int ii=0; ii<vnum.size(); ii++)
        {
            converter.as_dbl = vnum[ii];
            res.push_back(converter.as_int);
        }
        return res;
    }
}

TimsDataHandle::TimsDataHandle(const std::string& tims_data_dir,
                               const Rcpp::List& analysis_tdf,
                               const Rcpp::CharacterVector& metadata_keys,
                               const Rcpp::CharacterVector& metadata_values,
                               pressure_compensation_strategy pcs) :
TimsDataHandle(tims_data_dir, pcs)
{
    for(R_xlen_t ii = 0; ii < metadata_keys.size(); ii++)
    {
        if(Rcpp::CharacterVector::is_na(metadata_keys[ii]) || Rcpp::CharacterVector::is_na(metadata_values[ii]))
            continue;
        global_metadata.emplace_back(Rcpp::as<std::string>(metadata_keys[ii]), Rcpp::as<std::string>(metadata_values[ii]));
    }

    for(const auto& [key, value] : global_metadata)
        if(key == "TimsCompressionType")
            check_compression_type(value.c_str());

    std::vector<uint32_t> ids = braindead_r_extract_as_int<uint32_t>(analysis_tdf("Id"));
    std::vector<uint32_t> num_scans = braindead_r_extract_as_int<uint32_t>(analysis_tdf("NumScans"));
    std::vector<uint32_t> num_peaks = braindead_r_extract_as_int<uint32_t>(analysis_tdf("NumPeaks"));
    std::vector<uint32_t> msms_type = braindead_r_extract_as_int<uint32_t>(analysis_tdf("MsMsType"));
    Rcpp::NumericVector accum_time = analysis_tdf("AccumulationTime");
    Rcpp::NumericVector time = analysis_tdf("Time");
    std::vector<uint64_t> tims_id = braindead_r_extract_as_int<uint64_t>(analysis_tdf("TimsId"));

    for(size_t ii = 0; ii < ids.size(); ii++)
    {
        frame_descs.emplace(ids[ii], TimsFrame(
                ids[ii],
                num_scans[ii],
                num_peaks[ii],
                msms_type[ii],
                100.0 / accum_time[ii],
                time[ii],
                tims_id[ii],
                *this));
    }

    init(pcs);
}
#endif

TimsDataHandle::~TimsDataHandle() {}


TimsFrame& TimsDataHandle::get_frame(uint32_t frame_no)
{
    return frame_descs.at(frame_no);
}

std::unordered_map<uint32_t, TimsFrame>& TimsDataHandle::get_frame_descs()
{
    return frame_descs;
}

size_t TimsDataHandle::no_peaks_in_frames(const uint32_t* indexes, size_t no_indexes)
{
    size_t ret = 0;
    for(size_t ii = 0; ii < no_indexes; ii++)
        ret += frame_descs.at(indexes[ii]).num_peaks;
    return ret;

}

size_t TimsDataHandle::no_peaks_in_slice(uint32_t start, uint32_t end, uint32_t step)
{
    if(step == 0)
        throw std::runtime_error("no_peaks_in_slice: step must be > 0");
    size_t ret = 0;
    for(uint64_t ii = start; ii < end; ii += step)
        ret += frame_descs.at(ii).num_peaks;
    return ret;
}

size_t TimsDataHandle::no_peaks_total() const
{
    size_t ret = 0;
    for(auto it = frame_descs.begin(); it != frame_descs.end(); it++)
        ret += it->second.num_peaks;
    return ret;
}

void TimsDataHandle::set_converter(std::unique_ptr<Tof2MzConverter>&& converter)
{
    if(converter)
        tof2mz_converter = std::move(converter);
    else
        tof2mz_converter = DefaultTof2MzConverterFactory::produceDefaultConverterInstance(*this);
}

void TimsDataHandle::set_converter(std::unique_ptr<Scan2InvIonMobilityConverter>&& converter)
{
    if(converter)
        scan2inv_ion_mobility_converter = std::move(converter);
    else
        scan2inv_ion_mobility_converter = DefaultScan2InvIonMobilityConverterFactory::produceDefaultConverterInstance(*this);
}

void TimsDataHandle::extract_frames(const uint32_t* indexes,
                                    size_t no_indexes,
                                    uint32_t* result)
{
    size_t no_peaks = no_peaks_in_frames(indexes, no_indexes);

    uint32_t* offset0 = result;
    uint32_t* offset1 = offset0 + no_peaks;
    uint32_t* offset2 = offset1 + no_peaks;
    uint32_t* offset3 = offset2 + no_peaks;

    for(size_t ii = 0; ii < no_indexes; ii++)
    {
        TimsFrame& frame = frame_descs.at(indexes[ii]);
        frame.save_to_buffs(offset0, offset1, offset2, offset3, nullptr, nullptr, nullptr, zstd_dctx.get());
        offset0 += frame.num_peaks;
        offset1 += frame.num_peaks;
        offset2 += frame.num_peaks;
        offset3 += frame.num_peaks;
    }
}


void TimsDataHandle::extract_frames_slice(uint32_t start,
                                          uint32_t end,
                                          uint32_t step,
                                          uint32_t* result)
{
    if(step == 0)
        throw std::runtime_error("extract_frames_slice: step must be > 0");
    size_t no_peaks = no_peaks_in_slice(start, end, step);

    uint32_t* offset0 = result;
    uint32_t* offset1 = offset0 + no_peaks;
    uint32_t* offset2 = offset1 + no_peaks;
    uint32_t* offset3 = offset2 + no_peaks;

    for(uint64_t ii = start; ii < end; ii += step)
    {
        TimsFrame& frame = frame_descs.at(ii);
        frame.save_to_buffs(offset0, offset1, offset2, offset3, nullptr, nullptr, nullptr, zstd_dctx.get());
        offset0 += frame.num_peaks;
        offset1 += frame.num_peaks;
        offset2 += frame.num_peaks;
        offset3 += frame.num_peaks;
    }
}

#define move_ptr(ptr) if(ptr) ptr += n;

void TimsDataHandle::extract_frames(const uint32_t* indexes,
                                    size_t no_indexes,
                                    uint32_t* frame_ids,
                                    uint32_t* scan_ids,
                                    uint32_t* tofs,
                                    uint32_t* intensities,
                                    double* mzs,
                                    double* inv_ion_mobilities,
                                    double* retention_times)
{
    for(size_t ii = 0; ii < no_indexes; ii++)
    {
        TimsFrame& frame = frame_descs.at(indexes[ii]);
        const size_t n = frame.num_peaks;
        frame_descs.at(indexes[ii]).save_to_buffs(frame_ids, scan_ids, tofs, intensities, mzs, inv_ion_mobilities, retention_times, zstd_dctx.get());
        move_ptr(frame_ids);
        move_ptr(scan_ids);
        move_ptr(tofs);
        move_ptr(intensities);
        move_ptr(mzs);
        move_ptr(inv_ion_mobilities);
        move_ptr(retention_times);
    }
}

void TimsDataHandle::extract_frames_slice(uint32_t start,
                                          uint32_t end,
                                          uint32_t step,
                                          uint32_t* frame_ids,
                                          uint32_t* scan_ids,
                                          uint32_t* tofs,
                                          uint32_t* intensities,
                                          double* mzs,
                                          double* inv_ion_mobilities,
                                          double* retention_times)
{
    if(step == 0)
        throw std::runtime_error("extract_frames_slice: step must be > 0");
    for(uint64_t ii = start; ii < end; ii += step)
    {
        TimsFrame& frame = frame_descs.at(ii);
        const size_t n = frame.num_peaks;
        frame_descs.at(ii).save_to_buffs(frame_ids, scan_ids, tofs, intensities, mzs, inv_ion_mobilities, retention_times, zstd_dctx.get());
        move_ptr(frame_ids);
        move_ptr(scan_ids);
        move_ptr(tofs);
        move_ptr(intensities);
        move_ptr(mzs);
        move_ptr(inv_ion_mobilities);
        move_ptr(retention_times);
    }
}



size_t TimsDataHandle::max_peaks_in_frame()
{
    size_t ret = 0;
    for(auto it = frame_descs.begin(); it != frame_descs.end(); it++)
        if(it->second.num_peaks > ret)
            ret = it->second.num_peaks;
    return ret;
}

void TimsDataHandle::allocate_buffers()
{
    size_t size = max_peaks_in_frame();
    _scan_ids_buffer = std::make_unique<uint32_t[]>(size);
    _tofs_buffer = std::make_unique<uint32_t[]>(size);
    _intensities_buffer = std::make_unique<uint32_t[]>(size);
}

void TimsDataHandle::free_buffers()
{
    _scan_ids_buffer = nullptr;
    _tofs_buffer = nullptr;
    _intensities_buffer = nullptr;
}

size_t TimsDataHandle::expose_frame(size_t frame_no)
{
    ensure_buffers_allocated();
    TimsFrame& frame = get_frame(frame_no);
    frame.save_to_buffs(nullptr, _scan_ids_buffer.get(), _tofs_buffer.get(), _intensities_buffer.get(), nullptr, nullptr, nullptr, zstd_dctx.get());
    return frame.num_peaks;
}

void TimsDataHandle::extract_frames(const std::vector<uint32_t>& indexes,
                                    uint32_t* const * frame_ids,
                                    uint32_t* const * scan_ids,
                                    uint32_t* const * tofs,
                                    uint32_t* const * intensities,
                                    double* const * mzs,
                                    double* const * inv_ion_mobilities,
                                    double* const * retention_times)
{
    if(indexes.empty())
        return;
    std::atomic<size_t> current_task(0);
    // An exception escaping a std::thread calls std::terminate, killing the
    // host interpreter; keep the first one and rethrow it after joining.
    std::exception_ptr first_error;
    std::mutex first_error_mutex;

    // Restore converter threading on every exit, after all workers have joined.
    struct RestoreConverterThreading
    {
        ~RestoreConverterThreading() { ThreadingManager::get_instance().set_converter_threading(); }
    } restore_threading;
    ThreadingManager::get_instance().set_shared_threading();
    size_t n_threads = (std::min)(indexes.size(),
        (std::max)(ThreadingManager::get_instance().get_no_opentims_threads(), size_t(1)));

    // Keep std::thread for older platform standard libraries. Join during
    // unwinding too, if a later thread constructor or vector allocation fails.
    std::vector<std::thread> threads;
    struct JoinThreads
    {
        std::vector<std::thread>& threads;
        ~JoinThreads()
        {
            for(auto& thread : threads)
                if(thread.joinable()) thread.join();
        }
    } join_threads{threads};
    for(size_t ii=0; ii<n_threads; ii++)
        threads.emplace_back([&](){
            try
            {
                std::unique_ptr<ZSTD_DCtx, decltype(&ZSTD_freeDCtx)> zstd(ZSTD_createDCtx(), &ZSTD_freeDCtx);
                std::unique_ptr<char[]> decomp_buffer = std::make_unique<char[]>(decomp_buffer_size);
                while(true)
                {
                    size_t my_task = current_task.fetch_add(1);
                    if(my_task >= indexes.size())
                        break;
                    const TimsFrame& frame = get_frame(indexes[my_task]);
                    frame.save_to_buffs(frame_ids[my_task], scan_ids[my_task], tofs[my_task], intensities[my_task], mzs[my_task], inv_ion_mobilities[my_task], retention_times[my_task], decomp_buffer.get(), zstd.get());
                }
            }
            catch(...)
            {
                std::lock_guard<std::mutex> lock(first_error_mutex);
                if(!first_error)
                    first_error = std::current_exception();
                current_task = indexes.size(); // stop the other workers
            }
        });
    for (auto& th : threads) th.join();
    if(first_error)
        std::rethrow_exception(first_error);
}


void TimsDataHandle::per_frame_TIC(uint32_t* result)
{
    if(frame_descs.empty())
        return;
    std::fill(result, result + (size_t(_max_frame_id) - _min_frame_id + 1), uint32_t(0));

    const size_t m_peaks_in_frame = max_peaks_in_frame();
    if(m_peaks_in_frame == 0)
        return;
    std::unique_ptr<uint32_t[]> intensities = std::make_unique<uint32_t[]>(m_peaks_in_frame);

    for(auto it = frame_descs.begin(); it != frame_descs.end(); it++)
    {
        it->second.save_to_buffs(nullptr, nullptr, nullptr, intensities.get(), nullptr, nullptr, nullptr, zstd_dctx.get());
        uint32_t acc = 0;
        const size_t n_peaks = it->second.num_peaks;
        for(size_t ii = 0; ii < n_peaks; ii++)
            acc += intensities[ii];
        result[it->first - _min_frame_id] = acc;
    }
}
