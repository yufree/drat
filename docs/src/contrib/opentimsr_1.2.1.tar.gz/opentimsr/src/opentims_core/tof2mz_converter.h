/*
 *   OpenTIMS: a fully open-source library for opening Bruker's TimsTOF data files.
 *   Copyright (C) 2020-2026 Michał Startek and Mateusz Łącki
 *
 *   Licensed under the MIT License. See LICENCE file in the project root for details.
 */

#pragma once

#include <cstdint>
#include <memory>
#include <string>
#include "bruker_api.h"
#include "platform.h"

#ifdef OPENTIMS_BUILDING_R
#include "opentimsr_types.h"
#else
#include "opentims.h"
#endif

#include "so_manager.h"

class Tof2MzConverter
{
 public:
    virtual void convert(uint32_t frame_id, double* mzs, const double* tofs, uint32_t size) = 0;
    virtual void convert(uint32_t frame_id, double* mzs, const uint32_t* tofs, uint32_t size) = 0;
    virtual void inverse_convert(uint32_t frame_id, uint32_t* tofs, const double* mzs, uint32_t size) = 0;
    virtual ~Tof2MzConverter();
    virtual std::string description();
};

class ErrorTof2MzConverter : public Tof2MzConverter
{
 public:
    ErrorTof2MzConverter(TimsDataHandle&, pressure_compensation_strategy pcs = NoPressureCompensation);
    void convert(uint32_t, double*, const double*, uint32_t) override final;
    void convert(uint32_t, double*, const uint32_t*, uint32_t) override final;
    void inverse_convert(uint32_t frame_id, uint32_t* tofs, const double* mzs, uint32_t size) override final;
    std::string description() override final;
};

class BrukerTof2MzConverter final : public Tof2MzConverter
{
    const LoadedLibraryHandle lib_handle;
    uint64_t bruker_file_handle;

    tims_open_v2_fun_t* tims_open;
    tims_get_last_error_string_fun_t* tims_get_last_error_string;
    tims_close_fun_t* tims_close;
    tims_convert_fun_t* tims_index_to_mz;
    tims_convert_fun_t* tims_mz_to_index;

    std::string get_tims_error();

 public:
    BrukerTof2MzConverter(TimsDataHandle& TDH, const std::string& lib_path, pressure_compensation_strategy pcs = NoPressureCompensation);
    ~BrukerTof2MzConverter();

    void convert(uint32_t frame_id, double* mzs, const double* tofs, uint32_t size) override final;
    void convert(uint32_t frame_id, double* mzs, const uint32_t* tofs, uint32_t size) override final;
    void inverse_convert(uint32_t frame_id, uint32_t* tofs, const double* mzs, uint32_t size) override final;

    std::string description() override final;
};

class Tof2MzConverterFactory
{
 public:
    virtual std::unique_ptr<Tof2MzConverter> produce(TimsDataHandle& TDH, pressure_compensation_strategy pcs = NoPressureCompensation) = 0;
    virtual ~Tof2MzConverterFactory();
};

class ErrorTof2MzConverterFactory final : public Tof2MzConverterFactory
{
 public:
    static ErrorTof2MzConverterFactory& instance()
    {
        static ErrorTof2MzConverterFactory inst;
        return inst;
    }

    std::unique_ptr<Tof2MzConverter> produce(TimsDataHandle& TDH, pressure_compensation_strategy pcs = NoPressureCompensation) override final;
};

class BrukerTof2MzConverterFactory final : public Tof2MzConverterFactory
{
    const std::string dll_path;
    const LoadedLibraryHandle lib_hndl;
 public:
    BrukerTof2MzConverterFactory(const char* _dll_path);
    BrukerTof2MzConverterFactory(const std::string& _dll_path);
    static BrukerTof2MzConverterFactory& instance(const std::string& path);
    std::unique_ptr<Tof2MzConverter> produce(TimsDataHandle& TDH, pressure_compensation_strategy pcs = NoPressureCompensation) override final;
};

class DefaultTof2MzConverterFactory final
{
    static std::unique_ptr<Tof2MzConverterFactory> fac_instance;
 public:
    static std::unique_ptr<Tof2MzConverter> produceDefaultConverterInstance(TimsDataHandle& TDH, pressure_compensation_strategy pcs = NoPressureCompensation);

    template<class FactoryType, class... Args> static void setAsDefault(Args&& ... args)
    {
        static_assert(std::is_base_of<Tof2MzConverterFactory, FactoryType>::value, "FactoryType must be a subclass of Tof2MzConverterFactory");
        fac_instance = std::make_unique<FactoryType>(std::forward<Args>(args)...);
    }
};

/**
 * Open-source TOF-to-m/z converter using linear-in-sqrt calibration.
 *
 * sqrt(mz) = intercept + slope * tof_index
 * mz       = (intercept + slope * tof_index)^2
 *
 * Calibration parameters are derived from the GlobalMetadata table in
 * analysis.tdf: MzAcqRangeLower, MzAcqRangeUpper, DigitizerNumSamples.
 */
class OpenSourceTof2MzConverter : public Tof2MzConverter
{
public:
    OpenSourceTof2MzConverter(double mz_min, double mz_max, uint32_t tof_max_index,
                              bool is_otof_control = false);

    void convert(uint32_t frame_id, double* mzs, const double* tofs, uint32_t size) override;
    void convert(uint32_t frame_id, double* mzs, const uint32_t* tofs, uint32_t size) override;
    void inverse_convert(uint32_t frame_id, uint32_t* tofs, const double* mzs, uint32_t size) override;
    std::string description() override;

    void updateCalibration(double new_intercept, double new_slope);
    double intercept() const { return intercept_; }
    double slope() const { return slope_; }

private:
    double intercept_;
    double slope_;
};

class OpenSourceTof2MzConverterFactory : public Tof2MzConverterFactory
{
public:
    static OpenSourceTof2MzConverterFactory& instance()
    {
        static OpenSourceTof2MzConverterFactory inst;
        return inst;
    }

    std::unique_ptr<Tof2MzConverter> produce(TimsDataHandle& TDH,
        pressure_compensation_strategy pcs = NoPressureCompensation) override;
};
