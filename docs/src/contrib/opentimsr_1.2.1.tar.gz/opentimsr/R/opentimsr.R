# *   OpenTIMS: a fully open-source library for opening Bruker's TimsTOF data files.
# *   Copyright (C) 2020-2026 Michał Startek and Mateusz Łącki
# *
# *   Licensed under the MIT License. See LICENCE file in the project root for details.


#' @useDynLib opentimsr
#' @importFrom Rcpp sourceCpp
NULL

.onUnload <- function (libpath) {
  library.dynam.unload("opentimsr", libpath)
}

all_columns = c('frame','scan','tof','intensity','mz','inv_ion_mobility','retention_time')

# Validate user-given frame numbers here: the C++ side only reports 'unordered_map::at'.
check_frames <- function(opentims, frames){
  if(!is.numeric(frames) || anyNA(frames) || any(frames != trunc(frames)))
    stop("Frame numbers must be whole numbers, without NAs.", call.=FALSE)
  missing = setdiff(frames, opentims@frames$Id)
  if(length(missing) > 0)
    stop(sprintf("No such frame(s): %s. The dataset has frames %d to %d.",
                 paste(head(missing, 5), collapse=", "), opentims@min_frame, opentims@max_frame),
         call.=FALSE)
  as.integer(frames)
}

# Validate a from:to:by slice; 'to' is exclusive. An empty slice (from >= to) is allowed.
check_slice <- function(opentims, from, to, by){
  for(arg in list(from, to, by))
    if(!is.numeric(arg) || length(arg) != 1 || is.na(arg) || arg != trunc(arg))
      stop("'from', 'to' and 'by' must be single whole numbers.", call.=FALSE)
  if(by < 1)
    stop("'by' must be positive.", call.=FALSE)
  if(from < to && (from < opentims@min_frame || to > opentims@max_frame + 1))
    stop(sprintf("Frames %d to %d are out of range. The dataset has frames %d to %d.",
                 as.integer(from), as.integer(to - 1), opentims@min_frame, opentims@max_frame),
         call.=FALSE)
  invisible(NULL)
}


#' TimsTOF data accessor.
#'
#' S4 class that facilitates data queries for TimsTOF data.
#'
#' @slot path.d Path to raw data folder (typically *.d).
#' @slot handle Pointer to raw data.
#' @slot min_frame The index of the minimal frame.
#' @slot max_frame The index of the miximal frame.
#' @slot min_scan The minimal scan number: 0, as scans are numbered from 0, like in Bruker's own tables and libraries.
#' @slot max_scan The maximal scan number: the largest NumScans minus 1.
#' @slot min_intensity The minimal value of intensity. Set to 0, but actually 9 is more sensible.
#' @slot max_intensity The maximal intensity: the max over values reported in the frames.
#' @slot min_retention_time The lowest recorded retention time.
#' @slot max_retention_time The highest recorded retention time.
#' @slot min_inv_ion_mobility The minimal recorded inverse ion mobility.
#' @slot max_inv_ion_mobility The maximal recorded inverse ion mobility.
#' @slot min_mz The minimal recorded mass to charge ratio.
#' @slot max_mz The maximal recorded mass to charge ratio.
#' @slot frames A data.frame with information on the frames (contents of the Frames table in the sqlite db).
#' @slot all_columns Names of available columns.
#' @export
setClass('OpenTIMS',
         slots = c(path.d='character',
                   handle='externalptr',
                   min_frame='integer',
                   max_frame='integer',
                   min_scan='integer',
                   max_scan='integer',
                   min_intensity='integer',
                   max_intensity='integer',
                   min_retention_time='numeric',
                   max_retention_time='numeric',
                   min_inv_ion_mobility='numeric',
                   max_inv_ion_mobility='numeric',
                   min_mz='numeric',
                   max_mz='numeric',
                   frames='data.frame',
                   all_columns='character')
)

setMethod('show',
          'OpenTIMS',
          function(object) 
            cat(paste0(class(object),
                        "(",
                        tdf_no_peaks_total(object@handle),
                        ")",
                        "\n",
                        separator='')))

#' Get the overall number of peaks.
#'
#' @param x OpenTIMS data instance.
#' @return The total number of peaks in the dataset.
#' @examples
#' path.d = system.file("extdata", "test.d", package = "opentimsr")
#' setup_opensource()
#' D = OpenTIMS(path.d)
#' length(D) # number of peaks in the dataset
#' CloseTIMS(D)
setMethod('length', 
          'OpenTIMS', 
          function(x) tdf_no_peaks_total(x@handle))

#' Get some frames of data.
#'
#' @param x OpenTIMS data instance.
#' @param i Frame numbers to extract.
#' @return For the requested frames, a data.frame with columns 'frame', 'scan', 'tof' and 'intensity', one row per peak.
#' @examples
#' path.d = system.file("extdata", "test.d", package = "opentimsr")
#' setup_opensource()
#' D = OpenTIMS(path.d)
#' head(D[1])   # first frame
#' head(D[1:2]) # frames 1 and 2
#' CloseTIMS(D)
setMethod("[", 
          signature(x = "OpenTIMS", i = "ANY"),
          function(x, i){
            return(tdf_get_indexes(x@handle, check_frames(x, i)))
        })

#' Select a range of frames to extract.
#'
#' This is similar to using the from:to:by operator in Python.
#'
#' @param x OpenTIMS data instance.
#' @param from The first frame to extract.
#' @param to The last+1 frame to extract. Frame with that number will not get extracted, but some below that number might.
#' @param by Extract each by-th frame.
#' @param na.rm Needed to comply with the generic. There should not be any NA frames, 
#' since the from and to are checked against the limits of the data.
#' @return For the selected frames, a data.frame with columns 'frame', 'scan', 'tof' and 'intensity', one row per peak.
#' @examples
#' path.d = system.file("extdata", "test.d", package = "opentimsr")
#' setup_opensource()
#' D = OpenTIMS(path.d)
#' head(range(D, 1, 3))    # frames 1 and 2
#' head(range(D, 1, 3, 2)) # every second frame, i.e. only frame 1
#' CloseTIMS(D)
setMethod("range", 
          "OpenTIMS",
          function(x, from, to, by=1L, na.rm=FALSE){ 
            check_slice(x, from, to, by)
            tdf_get_range(x@handle, from, to, by)
          })

#' Extract tables from sqlite database analysis.tdf.
#'
#' Export a table from sqlite.
#'
#' @param opentims Instance of OpenTIMS
#' @param names Names to extract from the sqlite database.
#' @return A list of tables.
#' @export
#' @examples
#' path.d = system.file("extdata", "test.d", package = "opentimsr")
#' setup_opensource()
#' D = OpenTIMS(path.d)
#' head(table2df(D, "Frames")$Frames) # extract table "Frames"
#' CloseTIMS(D)
table2df <- function(opentims, names){
    analysis.tdf = file.path(opentims@path.d, 'analysis.tdf')
    sql_conn = DBI::dbConnect(RSQLite::SQLite(), analysis.tdf, flags=RSQLite::SQLITE_RO)
    on.exit(DBI::dbDisconnect(sql_conn))
    tables = lapply(names, function(name) DBI::dbReadTable(sql_conn, name))
    names(tables) = names
    return(tables)
}


#' Extract tables from sqlite database analysis.tdf.
#'
#' @param opentims Instance of OpenTIMS
#' @return Names of tables.
#' @export
#' @examples
#' path.d = system.file("extdata", "test.d", package = "opentimsr")
#' setup_opensource()
#' D = OpenTIMS(path.d)
#' tables_names(D)
#' CloseTIMS(D)
tables_names <- function(opentims){
    analysis.tdf = file.path(opentims@path.d, 'analysis.tdf')
    sql_conn = DBI::dbConnect(RSQLite::SQLite(), analysis.tdf, flags=RSQLite::SQLITE_RO)
    on.exit(DBI::dbDisconnect(sql_conn))
    tables_names = DBI::dbListTables(sql_conn)
    return(tables_names)
}



#' Get OpenTIMS data representation.
#' 
#' Select the converters for 'mz' and 'inv_ion_mobility' first, with
#' \code{\link{setup_opensource}} or \code{\link{setup_bruker_so}}; without
#' them, only the raw columns can be queried from the returned object.
#'
#' @param path.d Path to the TimsTOF '*.d' folder containing the data (requires the folder to contain only 'analysis.tdf' and 'analysis.tdf_bin').
#' @return An object of class \code{OpenTIMS}, used as the data handle by the other functions.
#' @examples
#' path.d = system.file("extdata", "test.d", package = "opentimsr")
#' setup_opensource()
#' D = OpenTIMS(path.d)
#' D[1] # first frame
#' CloseTIMS(D)
#' @importFrom methods new
#' @export
OpenTIMS <- function(path.d){
    # C++ side does not expand '~' nor resolve relative paths.
    path.d = normalizePath(path.d, mustWork=TRUE)
    # getting tables from SQlite
    analysis.tdf = file.path(path.d, 'analysis.tdf')
    sql_conn = DBI::dbConnect(RSQLite::SQLite(), analysis.tdf, flags=RSQLite::SQLITE_RO)
    on.exit(DBI::dbDisconnect(sql_conn))
    frames = DBI::dbReadTable(sql_conn, 'Frames')
    GlobalMetadata = DBI::dbReadTable(sql_conn, 'GlobalMetadata')
    handle = tdf_open(path.d, frames, GlobalMetadata$Key, GlobalMetadata$Value)
    GlobalMetadata = array(GlobalMetadata$Value, dimnames=list(GlobalMetadata$Key))

    ## Extracting basic info on the limits of reported measurements.
    ## Does not include TOF index

    # since we must use RSQLite anyway, we don't have to read it from C++
    # min_frame=as.integer(tdf_min_frame_id(handle)),
    # max_frame=as.integer(tdf_max_frame_id(handle)),
    min_frame = as.integer(min(frames$Id)) # just in case
    max_frame = as.integer(max(frames$Id)) # just in case
    # Scans are 0-based: a frame with NumScans scans has scans 0..NumScans-1.
    min_scan = 0L
    max_scan = as.integer(max(frames$NumScans)) - 1L
    min_intensity = 0L
    max_intensity = max(frames$MaxIntensity)
    min_retention_time = min(frames$Time)
    max_retention_time = max(frames$Time)
    min_inv_ion_mobility = as.numeric(GlobalMetadata['OneOverK0AcqRangeLower'])
    max_inv_ion_mobility = as.numeric(GlobalMetadata['OneOverK0AcqRangeUpper'])
    min_mz = as.numeric(GlobalMetadata['MzAcqRangeLower']) # would "float" be 
    max_mz = as.numeric(GlobalMetadata['MzAcqRangeUpper']) # a bad name to use?

    new("OpenTIMS",
        path.d=path.d,
        handle=handle,
        min_frame=min_frame,
        max_frame=max_frame,
        min_scan=min_scan,
        max_scan=max_scan,
        min_intensity=min_intensity,
        max_intensity=max_intensity,
        min_retention_time=min_retention_time,
        max_retention_time=max_retention_time,
        min_inv_ion_mobility=min_inv_ion_mobility,
        max_inv_ion_mobility=max_inv_ion_mobility,
        min_mz=min_mz,
        max_mz=max_mz,
        frames=frames,
        all_columns=all_columns)
}


#' Get border values for measurements.
#'
#' Get the min-max values of the measured variables (except for TOFs, that would require iteration through data rather than parsing metadata).
#' 
#' @param opentims Instance of OpenTIMS.
#' @return data.frame Limits of individual extracted quantities.
#' @export
#' @examples
#' path.d = system.file("extdata", "test.d", package = "opentimsr")
#' setup_opensource()
#' D = OpenTIMS(path.d)
#' min_max_measurements(D) # small data frame with min and max values
#' CloseTIMS(D)
min_max_measurements <- function(opentims){
    data.frame(stat=c('min','max'),
               frame=c(opentims@min_frame,opentims@max_frame),
               scan=c(opentims@min_scan, opentims@max_scan),
               intensity=c(opentims@min_intensity, opentims@max_intensity),
               retention.time=c(opentims@min_retention_time,
                                opentims@max_retention_time),
               inv_ion_mobility=c(opentims@min_inv_ion_mobility,
                                  opentims@max_inv_ion_mobility),
               mz=c(opentims@min_mz, opentims@max_mz))
}


#' Get MS1 frame numbers.
#'
#' @param opentims Instance of OpenTIMS
#' @return Numbers of frames corresponding to MS1, i.e. precursor ions.
#' @export
#' @examples
#' path.d = system.file("extdata", "test.d", package = "opentimsr")
#' setup_opensource()
#' D = OpenTIMS(path.d)
#' MS1(D)
#' CloseTIMS(D)
MS1 <- function(opentims) opentims@frames$Id[opentims@frames$MsMsType == 0]


#' Explore the contentents of the sqlite .tdf database.
#'
#' @param opentims Instance of OpenTIMS
#' @param ... Parameters passed to head and tail functions.
#' @return No return value, called for its side effect of printing the tables.
#' @importFrom utils head tail
#' @export
#' @examples
#' path.d = system.file("extdata", "test.d", package = "opentimsr")
#' setup_opensource()
#' D = OpenTIMS(path.d)
#' if (interactive()) explore.tdf.tables(D)
#' CloseTIMS(D)
explore.tdf.tables <- function(opentims, ...){
    for(table_name in tables_names(opentims)){
        print(table_name)
        df = table2df(opentims, table_name)
        print(head(df,...))
        print(tail(df,...))
        readline("PRESS ENTER")
    }
    print('Get full tables using "table2df".')
}


#' Get the number of peaks per frame.
#'
#' @param opentims Instance of OpenTIMS.
#' @return Number of peaks in each frame.
#' @export
#' @examples
#' path.d = system.file("extdata", "test.d", package = "opentimsr")
#' setup_opensource()
#' D = OpenTIMS(path.d)
#' peaks_per_frame_cnts(D)
#' CloseTIMS(D)
peaks_per_frame_cnts <- function(opentims){
  opentims@frames$NumPeaks
}


#' Get the retention time for each frame.
#'
#' @param opentims Instance of OpenTIMS.
#' @return Retention times corresponding to each frame.
#' @export
#' @examples
#' path.d = system.file("extdata", "test.d", package = "opentimsr")
#' setup_opensource()
#' D = OpenTIMS(path.d)
#' retention_times(D)
#' CloseTIMS(D)
retention_times <- function(opentims){
  opentims@frames$Time
}


#' Query for raw data.
#'
#' Get the raw data from Bruker's 'tdf_bin' format.
#' Defaults to both raw data ('frame','scan','tof','intensity') and its tranformations into physical units ('mz','inv_ion_mobility','retention_time').
#'
#' @param opentims Instance of OpenTIMS.
#' @param frames Vector of frame numbers to extract.
#' @param columns Vector of columns to extract. Defaults to all columns.
#' @return data.frame with selected columns.
#' @export
#' @examples
#' path.d = system.file("extdata", "test.d", package = "opentimsr")
#' setup_opensource()
#' D = OpenTIMS(path.d)
#' query(D, c(1, 2)) # extract all columns
#' query(D, c(1, 2), columns=c('scan','intensity')) # only 'scan' and 'intensity'
#' CloseTIMS(D)
query <- function(opentims,
                 frames,
                 columns=all_columns){
  col = opentims@all_columns %in% columns

  if(!all(columns %in% all_columns)) stop(paste0("Wrong column names. Choose among:\n", paste0(all_columns, sep=" ", collapse="")))

  df = tdf_extract_frames( opentims@handle,
                           check_frames(opentims, frames),
                           get_frames = col[1],
                           get_scans = col[2],
                           get_tofs = col[3],
                           get_intensities = col[4],
                           get_mzs = col[5],
                           get_inv_ion_mobilities = col[6],
                           get_retention_times = col[7] )

  as.data.frame(df)[,columns, drop=F] # What an idiot invented drop=T as default????
}


#' Query for raw data.
#'
#' Get the raw data from Bruker's 'tdf_bin' format.
#' Defaults to both raw data ('frame','scan','tof','intensity') and its tranformations into physical units ('mz','inv_ion_mobility','retention_time').
#'
#' We assume 'from' <= 'to'.
#'
#' @param opentims Instance of OpenTIMS.
#' @param from First frame to extract.
#' @param to Last frame to extract.
#' @param by Every by-th frame gets extracted (starting from the first one).
#' @param columns Vector of columns to extract. Defaults to all columns.
#' @return data.frame with selected columns.
#' @export
#' @examples
#' path.d = system.file("extdata", "test.d", package = "opentimsr")
#' setup_opensource()
#' D = OpenTIMS(path.d)
#' query_slice(D, 1, 2)    # frames 1 to 2
#' query_slice(D, 1, 2, 2) # every second frame between 1 and 2
#' query_slice(D, 1, 2, columns=c('scan','intensity')) # only 'scan' and 'intensity'
#' CloseTIMS(D)
query_slice <- function(opentims,
                       from=NULL,
                       to=NULL,
                       by=1,
                       columns=all_columns){
  col = opentims@all_columns %in% columns

  # Border conditions.
  if(is.null(from)) from = opentims@min_frame
  if(is.null(to)) to = opentims@max_frame
  check_slice(opentims, from, to + 1, by)

  df = tdf_extract_frames_slice( opentims@handle,
                                 from,
                                 to + 1, # For R numerations to work. 
                                 by,
                                 get_frames = col[1],
                                 get_scans = col[2],
                                 get_tofs = col[3],
                                 get_intensities = col[4],
                                 get_mzs = col[5],
                                 get_inv_ion_mobilities = col[6],
                                 get_retention_times = col[7] )
  as.data.frame(df)[,columns, drop=F] # What an idiot invented drop=T as default????
}


# Positions (not frame ids) in the retention time vector y bounding the closed interval.
get_left_position <- function(x,y) ifelse(x > y[length(y)], NA, findInterval(x, y, left.open=T) + 1)
get_right_position <- function(x,y) ifelse(x < y[1], NA, findInterval(x, y, left.open=F))


#' Get the retention time for each frame.
#'
#' Extract all frames corresponding to retention times inside [min_retention_time, max_retention_time] closed borders interval.
#'
#' @param opentims Instance of OpenTIMS.
#' @param min_retention_time Lower boundry on retention time.
#' @param max_retention_time Upper boundry on retention time.
#' @param columns Vector of columns to extract. Defaults to all columns.
#' @return data.frame with selected columns.
#' @export
#' @examples
#' path.d = system.file("extdata", "test.d", package = "opentimsr")
#' setup_opensource()
#' D = OpenTIMS(path.d)
#' rt_query(D, 0.6, 0.7) # frames recorded between 0.6 and 0.7 seconds
#' CloseTIMS(D)
rt_query <- function(opentims,
                    min_retention_time,
                    max_retention_time,
                    columns=all_columns){
  RTS = retention_times(opentims)

  first = get_left_position(min_retention_time, RTS)
  last = get_right_position(max_retention_time, RTS)

  if(is.na(first) | is.na(last))
    stop("The [min_retention_time,max_retention_time] interval does not hold any data.")

  # Map positions to frame ids: ids need not start at 1 nor be contiguous.
  frames = if(first <= last) opentims@frames$Id[first:last] else integer(0)
  query(opentims, frames, columns=columns)
}


#' Get Bruker's code needed for running proprietary time of flight to mass over charge and scan to drift time conversion. 
#'
#' Bruker's 'timsdata' library is proprietary software owned by Bruker. It is not
#' part of opentimsr and is not distributed with it: this function downloads it
#' only when called, from "https://github.com/MatteoLacki/opentims_bruker_bridge",
#' and by using it you agree to the license terms stated there.
#' The library is available only for 64-bit x86 Linux and Windows; elsewhere this
#' function stops with an error. opentimsr works without it,
#' using its built-in open-source converters (see \code{\link{setup_opensource}}).
#'
#' @param target.folder Folder where to store the 'dll' or 'so' file.
#' @param net_url The url with location of all files.
#' @param mode Which mode to use when downloading a file?
#' @param ... Other parameters to 'download.file'.
#' @return Path to the output 'timsdata.dll' on Windows and 'libtimsdata.so' on Linux.
#' @importFrom utils download.file
#' @export
#' @examples
#' \dontrun{
#' download_bruker_proprietary_code("your/prefered/destination/folder")
#' }
download_bruker_proprietary_code <- function(
  target.folder, 
  net_url=paste0("https://raw.githubusercontent.com/MatteoLacki/",
                 "opentims_bruker_bridge/main/opentims_bruker_bridge/"),
  mode="wb",
  ...){
  # Bruker's library exists only for 64-bit x86 Linux and Windows; what matters
  # is the architecture of R itself, since R loads the library.
  sysname = Sys.info()[['sysname']]
  arch = R.version$arch
  if(!(sysname %in% c("Linux", "Windows")) || !(arch %in% c("x86_64", "x86-64", "amd64")))
    stop(sprintf(paste0("Bruker's proprietary library is available only for 64-bit x86 Linux ",
                        "and Windows, not for %s on %s. Use the built-in open-source ",
                        "converters instead: see ?setup_opensource."), sysname, arch),
         call.=FALSE)
  if(sysname == "Linux"){
    message("Downloading 64-bit Linux binary.")
    url_ending = file = "libtimsdata.so"
  } else {
    message("Downloading Windows 64-bit binary.")
    file = "timsdata.dll"
    url_ending = "win64/timsdata.dll"
  }
  url = paste0(net_url, url_ending)
  target.file = file.path(target.folder, file)
  message("Downloading from: ", url)
  download.file(url, target.file, mode=mode, ...)

  target.file
}



#' Close the TIMS data handle and release all resources.
#'
#' Calling this method is not mandatory - the resources will anyway
#' be cleanly released when the garbage collector decides to
#' destroy the OpenTIMS data handle. The only purpose of this
#' method is to enable them to be explicitly released earlier than that.
#'
#' @param opentims Instance of OpenTIMS.
#' @return No return value, called for its side effect of closing the data handle.
#' @export
#' @examples
#' path.d = system.file("extdata", "test.d", package = "opentimsr")
#' setup_opensource()
#' D = OpenTIMS(path.d)
#' CloseTIMS(D)
CloseTIMS <- function(opentims){
    tdf_close(opentims@handle)
}


#' Dynamically link Bruker's DLL to enable tof-mz and scan-inv_ion_mobility conversion.
#'
#' Bruker's 'timsdata' library is proprietary software owned by Bruker. It is not
#' part of opentimsr and is not distributed with it; obtain it with
#' \code{\link{download_bruker_proprietary_code}}, whose license terms apply.
#' The library is available only for 64-bit x86 Linux and Windows. opentimsr works without it,
#' using its built-in open-source converters (see \code{\link{setup_opensource}}).
#'
#' @param path Path to the 'libtimsdata.so' on Linux or 'timsdata.dll' on Windows, as produced by 'download_bruker_proprietary_code'.
#' @return No return value, called for its side effect of switching the conversion backend.
#' @export
#' @examples
#' \dontrun{
#' so_path = download_bruker_proprietary_code("your/prefered/destination/folder")
#' setup_bruker_so(so_path)
#' }
setup_bruker_so <- function(path) .setup_bruker_so(path)


#' Use the built-in open-source tof-to-mz and scan-to-inv_ion_mobility converters.
#'
#' Activates the built-in open-source converters for tof-to-mz and
#' scan-to-inv_ion_mobility transformations. No proprietary Bruker libraries
#' are required.
#'
#' No converters are selected when the package is loaded: call either this
#' function or \code{\link{setup_bruker_so}} before \code{\link{OpenTIMS}}.
#' The choice is fixed when a dataset is opened. A dataset opened before either
#' is called still returns the raw columns ('frame', 'scan', 'tof', 'intensity'), but
#' requesting 'mz' or 'inv_ion_mobility' raises an error.
#'
#' @return No return value, called for its side effect of switching the conversion backend.
#' @examples
#' setup_opensource()
#' @export
setup_opensource <- function() invisible(.setup_opensource())


#' Set the number of threads to be used for data processing by OpenTIMS
#'
#' A value of 0 is acceptable: it will cause OpenTIMS to use all detected cores.
#'
#' @param n The number of worker threads to be used.
#' @return No return value, called for its side effect of setting the number of threads.
#' @export
#' @examples
#' opentims_set_threads(1)
opentims_set_threads <- function(n){
    tdf_set_num_threads(n)
}
