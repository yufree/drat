library(XMLSchema)
query  = readSchema("~/GitWorkingArea/XMLSchema/inst/samples/egquery.xsd")
defineClasses(query)


